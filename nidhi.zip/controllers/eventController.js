const Event = require('../models/Event');
const User = require('../models/User');
const Registration = require('../models/Registration');
const AdminLog = require('../models/AdminLog');

// @route   GET /api/v1/events
// @desc    Get all events with filters
// @access  Public
const getAllEvents = async (req, res, next) => {
  try {
    const { category, status, college, search, page = 1, limit = 10 } = req.query;

    let filter = {};

    if (category) filter.category = category;
    if (status) filter.status = status;
    if (college) filter.collegeName = { $regex: college, $options: 'i' };
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }

    const skip = (page - 1) * limit;
    const events = await Event.find(filter)
      .sort({ startDate: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Event.countDocuments(filter);

    res.json({
      success: true,
      data: events,
      pagination: {
        total,
        page: parseInt(page),
        pages: Math.ceil(total / limit),
        limit: parseInt(limit)
      }
    });
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/v1/events/:id
// @desc    Get event by ID
// @access  Public
const getEventById = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id)
      .populate('createdBy', 'name email college');

    if (!event) {
      return res.status(404).json({
        success: false,
        message: 'Event not found'
      });
    }

    res.json({
      success: true,
      data: event
    });
  } catch (error) {
    next(error);
  }
};

// @route   POST /api/v1/events
// @desc    Create new event
// @access  Private (college_admin, super_admin)
const createEvent = async (req, res, next) => {
  try {
    const { title, description, category, location, startDate, endDate, totalSlots, image, requirements, prizes, rules, contactEmail, contactPhone, entryFee } = req.body;

    // Get college name from user
    const user = await User.findById(req.user.id);

    const newEvent = new Event({
      title,
      description,
      category,
      location,
      startDate: new Date(startDate),
      endDate: new Date(endDate),
      totalSlots,
      image: image || null,
      requirements: requirements || '',
      prizes: prizes || '',
      rules: rules || '',
      contactEmail: contactEmail || '',
      contactPhone: contactPhone || '',
      entryFee: entryFee || 0,
      collegeId: req.user.id,
      collegeName: user.college,
      createdBy: req.user.id,
      status: 'upcoming'
    });

    await newEvent.save();

    await AdminLog.create({
      action: 'create',
      userId: req.user.id,
      entityType: 'event',
      entityId: newEvent._id,
      changes: { title: newEvent.title, status: newEvent.status },
      ipAddress: req.ip || '',
      userAgent: req.get('user-agent') || ''
    });

    res.status(201).json({
      success: true,
      message: 'Event created successfully',
      data: newEvent
    });
  } catch (error) {
    next(error);
  }
};

// @route   PUT /api/v1/events/:id
// @desc    Update event
// @access  Private (college_admin, super_admin - own events)
const updateEvent = async (req, res, next) => {
  try {
    let event = await Event.findById(req.params.id);

    if (!event) {
      return res.status(404).json({
        success: false,
        message: 'Event not found'
      });
    }

    // Check if user is owner or super_admin
    if (event.createdBy.toString() !== req.user.id && req.user.role !== 'super_admin') {
      return res.status(403).json({
        success: false,
        message: 'You do not have permission to update this event'
      });
    }

    event = await Event.findByIdAndUpdate(
      req.params.id,
      { $set: req.body },
      { new: true, runValidators: true }
    );

    await AdminLog.create({
      action: 'update',
      userId: req.user.id,
      entityType: 'event',
      entityId: event._id,
      changes: req.body,
      ipAddress: req.ip || '',
      userAgent: req.get('user-agent') || ''
    });

    res.json({
      success: true,
      message: 'Event updated successfully',
      data: event
    });
  } catch (error) {
    next(error);
  }
};

// @route   DELETE /api/v1/events/:id
// @desc    Delete event
// @access  Private (college_admin, super_admin - own events)
const deleteEvent = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id);

    if (!event) {
      return res.status(404).json({
        success: false,
        message: 'Event not found'
      });
    }

    // Check if user is owner or super_admin
    if (event.createdBy.toString() !== req.user.id && req.user.role !== 'super_admin') {
      return res.status(403).json({
        success: false,
        message: 'You do not have permission to delete this event'
      });
    }

    await Event.findByIdAndDelete(req.params.id);

    // Delete all registrations for this event
    await Registration.deleteMany({ eventId: req.params.id });

    await AdminLog.create({
      action: 'delete',
      userId: req.user.id,
      entityType: 'event',
      entityId: req.params.id,
      changes: { title: event.title },
      ipAddress: req.ip || '',
      userAgent: req.get('user-agent') || ''
    });

    res.json({
      success: true,
      message: 'Event deleted successfully'
    });
  } catch (error) {
    next(error);
  }
};

// @route   PATCH /api/v1/events/:id/status
// @desc    Update event status
// @access  Private (college_admin, super_admin - own events)
const updateEventStatus = async (req, res, next) => {
  try {
    const { status } = req.body;

    const event = await Event.findById(req.params.id);

    if (!event) {
      return res.status(404).json({
        success: false,
        message: 'Event not found'
      });
    }

    // Check if user is owner or super_admin
    if (event.createdBy.toString() !== req.user.id && req.user.role !== 'super_admin') {
      return res.status(403).json({
        success: false,
        message: 'You do not have permission to update this event'
      });
    }

    event.status = status;
    await event.save();

    await AdminLog.create({
      action: 'update',
      userId: req.user.id,
      entityType: 'event',
      entityId: event._id,
      changes: { newStatus: status },
      ipAddress: req.ip || '',
      userAgent: req.get('user-agent') || ''
    });

    res.json({
      success: true,
      message: 'Event status updated successfully',
      data: event
    });
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/v1/events/college/:collegeId
// @desc    Get events by college
// @access  Public
const getEventsByCollege = async (req, res, next) => {
  try {
    const events = await Event.find({ collegeId: req.params.collegeId })
      .sort({ startDate: -1 });

    res.json({
      success: true,
      data: events
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getAllEvents,
  getEventById,
  createEvent,
  updateEvent,
  deleteEvent,
  updateEventStatus,
  getEventsByCollege
};
