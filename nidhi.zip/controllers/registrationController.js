const Registration = require('../models/Registration');
const Event = require('../models/Event');

// @route   POST /api/v1/registrations
// @desc    Register user for event
// @access  Private
const registerForEvent = async (req, res, next) => {
  try {
    const { eventId } = req.body;
    const userId = req.user.id;

    // Check if user is a student
    if (req.user.role !== 'student') {
      return res.status(403).json({
        success: false,
        message: 'Only students are permitted to register for events.'
      });
    }

    // Check if event exists
    const event = await Event.findById(eventId);
    if (!event) {
      return res.status(404).json({
        success: false,
        message: 'Event not found'
      });
    }

    // Check if event is still open for registration
    if (event.status !== 'upcoming') {
      return res.status(400).json({
        success: false,
        message: 'Registration is closed. This event is ' + event.status + '.'
      });
    }

    // Check if user is already registered
    const existingRegistration = await Registration.findOne({ eventId, userId });
    if (existingRegistration) {
      return res.status(400).json({
        success: false,
        message: 'You are already registered for this event'
      });
    }

    // Check if slots are available
    if (event.registeredCount >= event.totalSlots) {
      return res.status(400).json({
        success: false,
        message: 'Event is full, no slots available'
      });
    }

    // Create registration
    const registration = new Registration({
      eventId,
      userId,
      status: 'pending'
    });

    await registration.save();

    // Update event registered count
    event.registeredCount += 1;
    await event.save();

    res.status(201).json({
      success: true,
      message: 'Successfully registered for event',
      data: registration
    });
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/v1/registrations/user/:userId
// @desc    Get user registrations
// @access  Private
const getUserRegistrations = async (req, res, next) => {
  try {
    const registrations = await Registration.find({ userId: req.params.userId })
      .populate('eventId', 'title description category startDate location status')
      .sort({ registrationDate: -1 });

    res.json({
      success: true,
      data: registrations
    });
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/v1/registrations/event/:eventId
// @desc    Get event registrations
// @access  Private (admin only)
const getEventRegistrations = async (req, res, next) => {
  try {
    const registrations = await Registration.find({ eventId: req.params.eventId })
      .populate('userId', 'name email college')
      .sort({ registrationDate: -1 });

    res.json({
      success: true,
      data: registrations
    });
  } catch (error) {
    next(error);
  }
};

// @route   PATCH /api/v1/registrations/:id/approve
// @desc    Approve registration
// @access  Private (admin only)
const approveRegistration = async (req, res, next) => {
  try {
    const registration = await Registration.findById(req.params.id);

    if (!registration) {
      return res.status(404).json({
        success: false,
        message: 'Registration not found'
      });
    }

    registration.status = 'approved';
    registration.approvalDate = new Date();
    await registration.save();

    res.json({
      success: true,
      message: 'Registration approved successfully',
      data: registration
    });
  } catch (error) {
    next(error);
  }
};

// @route   PATCH /api/v1/registrations/:id/reject
// @desc    Reject registration
// @access  Private (admin only)
const rejectRegistration = async (req, res, next) => {
  try {
    const { rejectionReason } = req.body;
    const registration = await Registration.findById(req.params.id);

    if (!registration) {
      return res.status(404).json({
        success: false,
        message: 'Registration not found'
      });
    }

    registration.status = 'rejected';
    registration.rejectionReason = rejectionReason || 'No reason provided';
    await registration.save();

    // Decrease event registered count
    const event = await Event.findById(registration.eventId);
    if (event && event.registeredCount > 0) {
      event.registeredCount -= 1;
      await event.save();
    }

    res.json({
      success: true,
      message: 'Registration rejected successfully',
      data: registration
    });
  } catch (error) {
    next(error);
  }
};

// @route   PATCH /api/v1/registrations/:id/cancel
// @desc    Cancel registration
// @access  Private
const cancelRegistration = async (req, res, next) => {
  try {
    const registration = await Registration.findById(req.params.id);

    if (!registration) {
      return res.status(404).json({
        success: false,
        message: 'Registration not found'
      });
    }

    // Check if user is owner or admin
    if (registration.userId.toString() !== req.user.id && req.user.role !== 'college_admin' && req.user.role !== 'super_admin') {
      return res.status(403).json({
        success: false,
        message: 'You do not have permission to cancel this registration'
      });
    }

    registration.status = 'cancelled';
    await registration.save();

    // Decrease event registered count
    const event = await Event.findById(registration.eventId);
    if (event && event.registeredCount > 0) {
      event.registeredCount -= 1;
      await event.save();
    }

    res.json({
      success: true,
      message: 'Registration cancelled successfully',
      data: registration
    });
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/v1/registrations/check/:eventId/:userId
// @desc    Check if user is registered for event
// @access  Public
const checkUserRegistration = async (req, res, next) => {
  try {
    const { eventId, userId } = req.params;

    const registration = await Registration.findOne({ eventId, userId });

    res.json({
      success: true,
      isRegistered: !!registration,
      data: registration || null
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  registerForEvent,
  getUserRegistrations,
  getEventRegistrations,
  approveRegistration,
  rejectRegistration,
  cancelRegistration,
  checkUserRegistration
};
