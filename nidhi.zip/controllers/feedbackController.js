const Feedback = require('../models/Feedback');
const AdminLog = require('../models/AdminLog');
const Event = require('../models/Event');

// @route   POST /api/v1/feedback
// @desc    Submit feedback for an event
// @access  Private
const submitFeedback = async (req, res, next) => {
  try {
    const { eventId, rating, comments } = req.body;
    const userId = req.user.id;

    // Check if event exists
    const event = await Event.findById(eventId);
    if (!event) {
      return res.status(404).json({
        success: false,
        message: 'Event not found'
      });
    }

    // Check if feedback already exists
    const existingFeedback = await Feedback.findOne({ eventId, userId });
    if (existingFeedback) {
      return res.status(400).json({
        success: false,
        message: 'You have already submitted feedback for this event'
      });
    }

    // Check if user is registered and approved for this event
    const Registration = require('../models/Registration');
    const registration = await Registration.findOne({ eventId, userId });
    if (!registration || registration.status !== 'approved') {
      return res.status(403).json({
        success: false,
        message: 'Only approved participants can submit feedback for this event'
      });
    }

    // Create feedback
    const feedback = new Feedback({
      eventId,
      userId,
      rating,
      comments
    });

    await feedback.save();

    // Log admin action
    await AdminLog.create({
      action: 'create',
      userId,
      entityType: 'feedback',
      entityId: feedback._id,
      changes: { rating, comments },
      ipAddress: req.ip,
      userAgent: req.get('user-agent')
    });

    res.status(201).json({
      success: true,
      message: 'Feedback submitted successfully',
      data: feedback
    });
  } catch (error) {
    next(error);
  }
};

// @route   PUT /api/v1/feedback/:id
// @desc    Update feedback
// @access  Private
const updateFeedback = async (req, res, next) => {
  try {
    const { rating, comments } = req.body;
    const feedback = await Feedback.findById(req.params.id);

    if (!feedback) {
      return res.status(404).json({
        success: false,
        message: 'Feedback not found'
      });
    }

    // Check if user is owner or admin
    if (feedback.userId.toString() !== req.user.id && req.user.role !== 'super_admin') {
      return res.status(403).json({
        success: false,
        message: 'You do not have permission to update this feedback'
      });
    }

    const oldData = {
      rating: feedback.rating,
      comments: feedback.comments
    };

    feedback.rating = rating || feedback.rating;
    feedback.comments = comments || feedback.comments;
    await feedback.save();

    // Log admin action
    await AdminLog.create({
      action: 'update',
      userId: req.user.id,
      entityType: 'feedback',
      entityId: feedback._id,
      changes: {
        oldData,
        newData: { rating: feedback.rating, comments: feedback.comments }
      },
      ipAddress: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({
      success: true,
      message: 'Feedback updated successfully',
      data: feedback
    });
  } catch (error) {
    next(error);
  }
};

// @route   DELETE /api/v1/feedback/:id
// @desc    Delete feedback
// @access  Private
const deleteFeedback = async (req, res, next) => {
  try {
    const feedback = await Feedback.findById(req.params.id);

    if (!feedback) {
      return res.status(404).json({
        success: false,
        message: 'Feedback not found'
      });
    }

    // Check if user is owner or admin
    if (feedback.userId.toString() !== req.user.id && req.user.role !== 'super_admin') {
      return res.status(403).json({
        success: false,
        message: 'You do not have permission to delete this feedback'
      });
    }

    await Feedback.findByIdAndDelete(req.params.id);

    // Log admin action
    await AdminLog.create({
      action: 'delete',
      userId: req.user.id,
      entityType: 'feedback',
      entityId: req.params.id,
      changes: feedback.toObject(),
      ipAddress: req.ip,
      userAgent: req.get('user-agent')
    });

    res.json({
      success: true,
      message: 'Feedback deleted successfully'
    });
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/v1/feedback/event/:eventId
// @desc    Get all feedback for an event
// @access  Public
const getEventFeedback = async (req, res, next) => {
  try {
    const feedback = await Feedback.find({ eventId: req.params.eventId })
      .populate('userId', 'name college')
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      count: feedback.length,
      data: feedback
    });
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/v1/feedback/stats/:eventId
// @desc    Get feedback statistics for event
// @access  Public
const getFeedbackStats = async (req, res, next) => {
  try {
    const feedbacks = await Feedback.find({ eventId: req.params.eventId });

    if (feedbacks.length === 0) {
      return res.json({
        success: true,
        stats: {
          totalFeedback: 0,
          averageRating: 0,
          ratingDistribution: {
            1: 0,
            2: 0,
            3: 0,
            4: 0,
            5: 0
          }
        }
      });
    }

    const totalFeedback = feedbacks.length;
    const totalRating = feedbacks.reduce((sum, fb) => sum + fb.rating, 0);
    const averageRating = (totalRating / totalFeedback).toFixed(2);

    const ratingDistribution = {
      1: feedbacks.filter(fb => fb.rating === 1).length,
      2: feedbacks.filter(fb => fb.rating === 2).length,
      3: feedbacks.filter(fb => fb.rating === 3).length,
      4: feedbacks.filter(fb => fb.rating === 4).length,
      5: feedbacks.filter(fb => fb.rating === 5).length
    };

    res.json({
      success: true,
      stats: {
        totalFeedback,
        averageRating: parseFloat(averageRating),
        ratingDistribution
      }
    });
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/v1/feedback/admin/logs
// @desc    Get admin logs
// @access  Private (super_admin only)
const getAdminLogs = async (req, res, next) => {
  try {
    const { action, entityType, page = 1, limit = 20 } = req.query;
    let filter = {};

    if (action) filter.action = action;
    if (entityType) filter.entityType = entityType;

    const skip = (page - 1) * limit;
    const logs = await AdminLog.find(filter)
      .populate('userId', 'name email role')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await AdminLog.countDocuments(filter);

    res.json({
      success: true,
      count: logs.length,
      total,
      page: parseInt(page),
      limit: parseInt(limit),
      data: logs
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  submitFeedback,
  updateFeedback,
  deleteFeedback,
  getEventFeedback,
  getFeedbackStats,
  getAdminLogs
};
