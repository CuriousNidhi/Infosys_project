const User = require('../models/User');
const AdminLog = require('../models/AdminLog');

// @route   GET /api/v1/users
// @desc    Get all users
// @access  Private (super_admin only)
const getAllUsers = async (req, res, next) => {
  try {
    const users = await User.find().select('-password').sort({ createdAt: -1 });

    res.json({
      success: true,
      count: users.length,
      data: users
    });
  } catch (error) {
    next(error);
  }
};

// @route   DELETE /api/v1/users/:id
// @desc    Delete user
// @access  Private (super_admin only)
const deleteUser = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Prevent deleting oneself
    if (user.id === req.user.id) {
      return res.status(400).json({
        success: false,
        message: 'You cannot delete yourself'
      });
    }

    await User.findByIdAndDelete(req.params.id);

    await AdminLog.create({
      action: 'delete',
      userId: req.user.id,
      entityType: 'user',
      entityId: req.params.id,
      changes: { deletedEmail: user.email },
      ipAddress: req.ip || '',
      userAgent: req.get('user-agent') || ''
    });

    res.json({
      success: true,
      message: 'User deleted successfully',
      data: {}
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getAllUsers,
  deleteUser
};
